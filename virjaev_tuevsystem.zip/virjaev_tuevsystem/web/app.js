const app = document.querySelector('#app');

const resource = typeof GetParentResourceName === 'function'
    ? GetParentResourceName()
    : 'esx_tuev';

const post = (name, data = {}) =>
    fetch(`https://${resource}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

window.tuevPost = post;

const closeTablet = () => post('close').catch(() => {});
window.closeTablet = closeTablet;

const date = t =>
    t
        ? new Date(t * 1000).toLocaleString('de-DE', {
            dateStyle: 'medium',
            timeStyle: 'short'
        })
        : 'Noch nie';

const esc = s =>
    String(s || 'Unbekannt').replace(
        /[&<>"']/g,
        c => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        }[c])
    );

function shell(content, cls = 'tablet') {
    app.className = '';
    app.innerHTML = `<section class="${cls}">${content}</section>`;
}

function header() {
    return `
        <div class="top">
            <div class="brand">
                <span class="brandmark">✓</span>
                TÜV <small>Digital</small>
            </div>

            <button class="x" onclick="closeTablet()">×</button>
        </div>
    `;
}

function vehicles(p) {
    shell(`
        <div class="screen">
            ${header()}

            <div class="eyebrow">Fahrzeugauswahl</div>
            <h1 class="heading">Welches Fahrzeug prüfen?</h1>
            <p class="sub">
                ${p.vehicles.length} Fahrzeug(e) in unmittelbarer Nähe gefunden
            </p>

            <div class="vehiclelist">
                ${p.vehicles.map(v => `
                    <button
                        class="vehicle"
                        onclick="tuevPost('selectVehicle', { netId: ${v.netId} })"
                    >
                        <span class="caricon">▰</span>

                        <span>
                            <b>${esc(v.label)}</b>
                            <span>${esc(v.plate)} · ${v.distance} m entfernt</span>
                        </span>

                        <span class="arrow">›</span>
                    </button>
                `).join('')}
            </div>
        </div>
    `);
}

function inspection(p) {
    const d = p.data;
    const valid = d.tuev_until > Date.now() / 1000;

    const cards = Object.entries({
        tires: ['Reifen', '◌'],
        body: ['Karosserie', '◇'],
        engine: ['Motor', '⚙'],
        windows: ['Scheiben', '▣']
    }).map(([key, [label, icon]]) => {
        const n = Math.round(d[key]);

        return `
            <article class="check">
                <div class="checktop">
                    <span>${label}</span>
                    <i>${icon}</i>
                </div>

                <div class="bar ${n < 35 ? 'low' : ''}">
                    <span style="width:${n}%"></span>
                </div>

                <div class="checktop">
                    <span>${n}% Qualität</span>
                </div>

                <button
                    class="repair"
                    onclick="tuevPost('repair', { component: '${key}' })"
                >
                    Reparatur starten
                </button>
            </article>
        `;
    }).join('');

    shell(`
        <div class="screen">
            ${header()}

            <div class="overview">
                <div>
                    <div class="eyebrow">Digitale Fahrzeugakte</div>
                    <h1 class="heading">Zustandsprüfung</h1>
                    <p class="sub">
                        ${esc(p.vehicle.label)} · ${esc(p.vehicle.plate)}
                    </p>

                    <div class="checks">
                        ${cards}
                    </div>
                </div>

                <aside>
                    <div class="tuev-card">
                        <div class="${valid ? 'valid' : 'expired'}">
                            ● ${valid ? 'TÜV AKTUELL' : 'TÜV ABGELAUFEN'}
                        </div>

                        <h3>${valid ? 'Schutz aktiv' : 'Prüfung erforderlich'}</h3>

                        <p>
                            ${
                                valid
                                    ? `Der Verschleiß ist bis <b>${date(d.tuev_until)}</b> eingefroren.`
                                    : 'Alle Bauteile verschleißen wieder durch gefahrene Kilometer.'
                            }
                        </p>

                        <div class="actions">
                            <button
                                class="pass"
                                onclick="tuevPost('tuev', { passed: true })"
                            >
                                ✓ Überprüfung bestanden
                            </button>

                            <button
                                class="fail"
                                onclick="tuevPost('tuev', { passed: false })"
                            >
                                Überprüfung nicht bestanden
                            </button>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    `);
}

function status(p) {
    const current = p.current;

    shell(`
        <div class="status-screen">
            <div class="brand" style="justify-content:center">
                <span class="brandmark">✓</span>
                TÜV Digital
            </div>

            <div class="seal">TÜV</div>

            <div class="${current ? 'valid' : 'expired'}">
                ● ${current ? 'TÜV AKTUELL' : 'TÜV ABGELAUFEN'}
            </div>

            <h1 class="status-title">${esc(p.plate)}</h1>

            <div class="status-body">
                <b>${current ? 'Prüfung gültig' : 'Keine gültige Prüfung'}</b>

                Die TÜV-Überprüfung wurde am
                <strong>${date(p.updatedAt)}</strong>
                das letzte Mal erneuert.

                <br><br>

                ${
                    current
                        ? `Diese gilt noch bis zum <strong>${date(p.untilTime)}</strong>.`
                        : 'Dieses Fahrzeug benötigt eine neue TÜV-Prüfung.'
                }
            </div>

            <button class="close-status" onclick="closeTablet()">
                Schließen
            </button>
        </div>
    `, 'status-wrap');
}

window.addEventListener('message', e => {
    const { action, payload } = e.data || {};

    if (action === 'close') {
        app.className = 'hidden';
        app.innerHTML = '';
    }

    if (action === 'vehicles') {
        vehicles(payload);
    }

    if (action === 'inspection') {
        inspection(payload);
    }

    if (action === 'status') {
        status(payload);
    }
});

document.addEventListener('keyup', e => {
    if (e.key === 'Escape') {
        closeTablet();
    }
});