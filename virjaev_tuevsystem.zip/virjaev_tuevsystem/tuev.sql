CREATE TABLE IF NOT EXISTS `tuev_vehicles` (
  `plate` varchar(16) NOT NULL,
  `tires` decimal(5,2) NOT NULL DEFAULT 100.00,
  `body` decimal(5,2) NOT NULL DEFAULT 100.00,
  `engine` decimal(5,2) NOT NULL DEFAULT 100.00,
  `windows` decimal(5,2) NOT NULL DEFAULT 100.00,
  `distance_buffer` decimal(10,3) NOT NULL DEFAULT 0.000,
  `tuev_until` bigint NOT NULL DEFAULT 0,
  `tuev_updated_at` bigint NOT NULL DEFAULT 0,
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Wichtig für bereits installierte Versionen:
-- Fügt die neue Kilometer-Zwischenspeicherung nur hinzu, falls sie fehlt.
SET @has_distance_buffer := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tuev_vehicles'
    AND COLUMN_NAME = 'distance_buffer'
);

SET @migration_sql := IF(
  @has_distance_buffer = 0,
  'ALTER TABLE `tuev_vehicles` ADD COLUMN `distance_buffer` decimal(10,3) NOT NULL DEFAULT 0.000 AFTER `windows`',
  'SELECT 1'
);

PREPARE tuev_migration FROM @migration_sql;
EXECUTE tuev_migration;
DEALLOCATE PREPARE tuev_migration;