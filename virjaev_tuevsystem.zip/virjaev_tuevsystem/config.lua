Config = {}

Config.TuevDurationDays = 7
Config.ScanRadius = 12.0
Config.DrivingReportInterval = 30000 -- ms
Config.MaxDistancePerReport = 8.0 -- km; Schutz gegen absurde Client-Reports
Config.RequiredJob = false -- z. B. 'mechanic', false = jeder mit Tablet
Config.RepairSkill = { 'easy', 'easy', 'medium' }

-- NPC-Fahrzeuge sind Fahrzeuge, die nicht in dieser Spielertabelle stehen.
-- Passe dies an, falls dein Server eine andere Fahrzeugtabelle nutzt.
Config.OwnedVehiclesTable = 'owned_vehicles'
Config.OwnedVehiclesPlateColumn = 'plate'

-- Beim ersten Erfassen erhalten NPC-Fahrzeuge einen zufälligen Zustand.
Config.NpcStartQuality = { min = 58, max = 88 }

-- Pro vollem gefahrenem Kilometer hat jede Statistik diese Chance,
-- genau einen Prozentpunkt zu verlieren.
Config.WearChancePerKm = 50

Config.Components = {
    tires = {
        label = 'Reifen',
        icon = '◌',
        repairLabel = 'Reifen erneuern',
        bones = { 'wheel_lf', 'wheel_rf', 'wheel_lr', 'wheel_rr' }
    },
    body = {
        label = 'Karosserie',
        icon = '◇',
        repairLabel = 'Karosserie instandsetzen',
        bones = { 'bonnet', 'boot' }
    },
    engine = {
        label = 'Motor',
        icon = '⚙',
        repairLabel = 'Motor warten',
        bones = { 'engine' }
    },
    windows = {
        label = 'Scheiben',
        icon = '▣',
        repairLabel = 'Scheiben ersetzen',
        bones = { 'windscreen', 'window_lf', 'window_rf' }
    }
}

-- Optional: Materialkosten über ox_inventory.
-- Auf false setzen, wenn Reparaturen gratis sein sollen.
Config.RepairItems = {
    tires = { name = 'repairkit', count = 1 },
    body = { name = 'repairkit', count = 1 },
    engine = { name = 'repairkit', count = 1 },
    windows = { name = 'glass', count = 1 }
}