local activeVehicle, repairTask, lastCoords, lastReport = nil, nil, nil, 0
local uiOpen = false

local function plate(vehicle) return (GetVehicleNumberPlateText(vehicle) or ''):gsub('^%s*(.-)%s*$', '%1'):upper() end
local function isDriver(vehicle) return GetPedInVehicleSeat(vehicle, -1) == PlayerPedId() end
-- Die FiveM-Client-Laufzeit stellt die Lua-Bibliothek `os` nicht bereit.
local function unixTime() return GetCloudTimeAsInt() end
local function sendUi(action, payload)
    SendNUIMessage({ action = action, payload = payload })
end
local function closeUi()
    uiOpen = false
    SetNuiFocus(false, false)
    sendUi('close')
end

local function openInspection(vehicle)
    if not DoesEntityExist(vehicle) then return end
    local data = lib.callback.await('esx_tuev:getVehicle', false, plate(vehicle))
    if not data then return end
    activeVehicle, uiOpen = vehicle, true
    SetNuiFocus(true, true)
    sendUi('inspection', { vehicle = { plate = data.plate, label = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle)) }, data = data, duration = Config.TuevDurationDays })
end

local function startRepair(component)
    if not activeVehicle or not DoesEntityExist(activeVehicle) then return lib.notify({ type = 'error', description = 'Fahrzeug nicht mehr gefunden.' }) end
    local componentData = Config.Components[component]
    repairTask = { vehicle = activeVehicle, component = component, boneIndex = 1 }
    closeUi()
    lib.notify({ type = 'inform', description = componentData.repairLabel .. ': Gehe zur markierten Fahrzeugstelle und drücke E.' })
end

RegisterNUICallback('selectVehicle', function(data, cb)
    openInspection(NetworkGetEntityFromNetworkId(data.netId)); cb(1)
end)
RegisterNUICallback('close', function(_, cb) closeUi(); cb(1) end)
RegisterNUICallback('repair', function(data, cb) startRepair(data.component); cb(1) end)
RegisterNUICallback('tuev', function(data, cb)
    if activeVehicle and DoesEntityExist(activeVehicle) then TriggerServerEvent('esx_tuev:setStatus', plate(activeVehicle), data.passed == true) end
    closeUi(); cb(1)
end)

exports('useTablet', function()
    local ped, coords, list = PlayerPedId(), GetEntityCoords(PlayerPedId()), {}
    for _, vehicle in ipairs(GetGamePool('CVehicle')) do
        local distance = #(GetEntityCoords(vehicle) - coords)
        if distance <= Config.ScanRadius then
            list[#list + 1] = { netId = NetworkGetNetworkIdFromEntity(vehicle), plate = plate(vehicle), label = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle)), distance = math.floor(distance * 10) / 10 }
        end
    end
    if #list == 0 then return lib.notify({ type = 'error', description = 'Kein Fahrzeug in der Nähe gefunden.' }) end
    table.sort(list, function(a,b) return a.distance < b.distance end)
    uiOpen = true; SetNuiFocus(true, true); sendUi('vehicles', { vehicles = list })
end)

exports.ox_target:addGlobalVehicle({
    { name = 'esx_tuev:status', icon = 'fa-solid fa-clipboard-check', label = 'TÜV-Status prüfen', distance = 2.5,
      onSelect = function(data)
          local details = lib.callback.await('esx_tuev:getVehicle', false, plate(data.entity))
          if not details then return end
          uiOpen = true; SetNuiFocus(true, true)
          sendUi('status', { plate = details.plate, untilTime = details.tuev_until, updatedAt = details.tuev_updated_at, current = details.tuev_until > unixTime() })
      end }
})

CreateThread(function()
    while true do
        local sleep = 1000
        if repairTask then
            local vehicle = repairTask.vehicle
            if not DoesEntityExist(vehicle) then repairTask = nil
            else
                sleep = 0
                local setting, boneName = Config.Components[repairTask.component], nil
                boneName = setting.bones[repairTask.boneIndex]
                local bone = GetEntityBoneIndexByName(vehicle, boneName)
                if bone == -1 then bone = 0 end
                local target = GetWorldPositionOfEntityBone(vehicle, bone)
                DrawMarker(2, target.x, target.y, target.z + .35, 0,0,0, 0,180,0, .18,.18,.18, 29,185,128,190, false,true,2,false,nil,nil,false)
                if #(GetEntityCoords(PlayerPedId()) - target) < 1.25 then
                    lib.showTextUI('[E] ' .. setting.repairLabel)
                    if IsControlJustReleased(0, 38) then
                        lib.hideTextUI()
                        if lib.skillCheck(Config.RepairSkill, { 'w', 'a', 's', 'd' }) then
                            local ok, result = lib.callback.await('esx_tuev:repair', false, plate(vehicle), repairTask.component)
                            if ok then
                                if repairTask.component == 'body' then SetVehicleFixed(vehicle) end
                                if repairTask.component == 'engine' then SetVehicleEngineHealth(vehicle, 1000.0) end
                                lib.notify({ type = 'success', description = setting.label .. ' ist wieder bei 100 %.' })
                            else lib.notify({ type = 'error', description = result }) end
                            repairTask = nil
                        else lib.notify({ type = 'error', description = 'Reparatur fehlgeschlagen.' }) end
                    end
                else lib.hideTextUI() end
            end
        end
        Wait(sleep)
    end
end)

CreateThread(function()
    while true do
        Wait(1000)
        local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
        if vehicle ~= 0 and isDriver(vehicle) then
            local coords, now = GetEntityCoords(vehicle), GetGameTimer()
            if lastCoords and now - lastReport >= Config.DrivingReportInterval then
                local km = #(coords - lastCoords) / 1000.0
                if km > 0 then
                    TriggerServerEvent('esx_tuev:reportDistance', plate(vehicle), km)
                    local data = lib.callback.await('esx_tuev:getVehicle', false, plate(vehicle))
                    if data and data.tuev_until <= unixTime() then
                        if data.engine < 30 then SetVehicleEnginePowerMultiplier(vehicle, -math.min(55, (30 - data.engine) * 1.8)) else SetVehicleEnginePowerMultiplier(vehicle, 0.0) end
                        if data.tires < 20 and math.random() < ((20 - data.tires) / 150) then SetVehicleTyreBurst(vehicle, math.random(0, 7), true, 1000.0) end
                        if data.windows < 18 and math.random() < ((18 - data.windows) / 180) then SmashVehicleWindow(vehicle, math.random(0, 7)) end
                    end
                end
                lastCoords, lastReport = coords, now
            elseif not lastCoords then lastCoords, lastReport = coords, now end
        else lastCoords = nil end
    end
end)

CreateThread(function() while true do Wait(0); if uiOpen and IsControlJustReleased(0, 200) then closeUi() end end end)
