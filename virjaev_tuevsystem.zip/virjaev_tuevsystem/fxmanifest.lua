fx_version 'cerulean'
game 'gta5'

author 'Codex'
description 'Modernes ESX TUEV- und Fahrzeugverschleiss-System'
version '1.0.0'

lua54 'yes'

ui_page 'web/index.html'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts { 'client.lua' }
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }

files { 'web/index.html', 'web/style.css', 'web/app.js' }

dependencies { 'es_extended', 'ox_lib', 'ox_target', 'ox_inventory', 'oxmysql' }
