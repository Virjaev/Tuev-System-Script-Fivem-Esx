local ESX = exports.es_extended:getSharedObject()

local function plate(value)
    return (value or ''):gsub('^%s*(.-)%s*$', '%1'):upper()
end

local function normalized(row)
    return {
        plate = row.plate,
        tires = tonumber(row.tires) or 100,
        body = tonumber(row.body) or 100,
        engine = tonumber(row.engine) or 100,
        windows = tonumber(row.windows) or 100,
        distance_buffer = tonumber(row.distance_buffer) or 0,
        tuev_until = row.tuev_until and tonumber(row.tuev_until) or 0,
        tuev_updated_at = row.tuev_updated_at and tonumber(row.tuev_updated_at) or 0
    }
end

local function getVehicleData(rawPlate)
    local p = plate(rawPlate)

    if p == '' then
        return nil
    end

    local row = MySQL.single.await(
        'SELECT * FROM tuev_vehicles WHERE plate = ?',
        { p }
    )

    if not row then
        local query = (
            'SELECT 1 FROM `%s` WHERE TRIM(`%s`) = ? LIMIT 1'
        ):format(Config.OwnedVehiclesTable, Config.OwnedVehiclesPlateColumn)

        local isOwned = MySQL.scalar.await(query, { p }) ~= nil

        -- Spielerfahrzeuge starten bei 100 %.
        -- Nicht gespeicherte / NPC-Fahrzeuge starten darunter.
        local quality = isOwned
            and 100
            or math.random(Config.NpcStartQuality.min, Config.NpcStartQuality.max)

        MySQL.insert.await(
            'INSERT INTO tuev_vehicles (plate, tires, body, engine, windows) VALUES (?, ?, ?, ?, ?)',
            { p, quality, quality, quality, quality }
        )

        return {
            plate = p,
            tires = quality,
            body = quality,
            engine = quality,
            windows = quality,
            distance_buffer = 0,
            tuev_until = 0,
            tuev_updated_at = 0
        }
    end

    return normalized(row)
end

local function hasJob(source)
    if not Config.RequiredJob then
        return true
    end

    local xPlayer = ESX.GetPlayerFromId(source)

    return xPlayer and xPlayer.job.name == Config.RequiredJob
end

lib.callback.register('esx_tuev:getVehicle', function(_, vehiclePlate)
    return getVehicleData(vehiclePlate)
end)

lib.callback.register('esx_tuev:repair', function(source, vehiclePlate, component)
    if not Config.Components[component] or not hasJob(source) then
        return false, 'Nicht berechtigt.'
    end

    local p = plate(vehiclePlate)
    local item = Config.RepairItems[component]

    if item and exports.ox_inventory:GetItemCount(source, item.name) < item.count then
        return false, ('Benötigt: %sx %s'):format(item.count, item.name)
    end

    if item then
        exports.ox_inventory:RemoveItem(source, item.name, item.count)
    end

    MySQL.update.await(
        ('UPDATE tuev_vehicles SET %s = 100 WHERE plate = ?'):format(component),
        { p }
    )

    return true, getVehicleData(p)
end)

RegisterNetEvent('esx_tuev:reportDistance', function(vehiclePlate, distance)
    if type(distance) ~= 'number' or distance <= 0 or distance > Config.MaxDistancePerReport then
        return
    end

    local data = getVehicleData(vehiclePlate)

    -- Bei aktivem TÜV werden keinerlei Kilometer oder Verschleiß gespeichert.
    if not data or data.tuev_until > os.time() then
        return
    end

    local totalDistance = data.distance_buffer + distance
    local completedKm = math.floor(totalDistance)

    -- Kilometerreste werden gespeichert, bis ein voller km erreicht wurde.
    if completedKm < 1 then
        MySQL.update.await(
            'UPDATE tuev_vehicles SET distance_buffer = ? WHERE plate = ?',
            { totalDistance, data.plate }
        )
        return
    end

    local losses = {
        tires = 0,
        body = 0,
        engine = 0,
        windows = 0
    }

    -- Pro vollem km: Jede Statistik hat unabhängig eine 50-%-Chance auf -1 %.
    for _ = 1, completedKm do
        for component in pairs(losses) do
            if math.random(1, 100) <= Config.WearChancePerKm then
                losses[component] = losses[component] + 1
            end
        end
    end

    MySQL.update.await([[
        UPDATE tuev_vehicles
        SET
            tires = GREATEST(0, tires - ?),
            body = GREATEST(0, body - ?),
            engine = GREATEST(0, engine - ?),
            windows = GREATEST(0, windows - ?),
            distance_buffer = ?
        WHERE plate = ?
    ]], {
        losses.tires,
        losses.body,
        losses.engine,
        losses.windows,
        totalDistance - completedKm,
        data.plate
    })
end)

RegisterNetEvent('esx_tuev:setStatus', function(vehiclePlate, passed)
    local source = source

    if not hasJob(source) then
        return
    end

    local p = plate(vehiclePlate)

    if passed then
        local now = os.time()
        local expiry = now + (Config.TuevDurationDays * 86400)

        MySQL.update.await(
            'UPDATE tuev_vehicles SET tuev_updated_at = ?, tuev_until = ? WHERE plate = ?',
            { now, expiry, p }
        )

        TriggerClientEvent('ox_lib:notify', source, {
            type = 'success',
            description = 'TÜV erfolgreich erneuert – Fahrzeug ist 7 Tage geschützt.'
        })
    else
        TriggerClientEvent('ox_lib:notify', source, {
            type = 'inform',
            description = 'TÜV als nicht bestanden markiert. Der Verschleiß bleibt aktiv.'
        })
    end
end)